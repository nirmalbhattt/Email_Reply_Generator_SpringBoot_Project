package com.email.writer;

import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class EmailGeneratorService {
    private final WebClient webClient;

    @Value("${gemini.api.url}")  // From application.properties
    private String geminiApiUrl;

    @Value("${gemini.api.key}")  // Never hardcode this!
    private String geminiApiKey;

    public EmailGeneratorService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();  // Ready for API calls
    }

    // Main method that ties everything together
    public String generateEmailReply(EmailRequest emailRequest) {
        // Step 1: Build the prompt we'll send to Gemini
        String prompt = buildPrompt(emailRequest);

        // Step 2: Prepare the request body (Gemini's expected format)
        Map<String, Object> requestBody = Map.of(
                "contents", new Object[] {
                        Map.of("parts", new Object[]{
                                Map.of("text", prompt)  // Our prompt goes here
                        })
                }
        );

        // Step 3: Call Gemini API
        String response = webClient.post()
                .uri(geminiApiUrl + "?key=" + geminiApiKey)  // Add API key
                .header("Content-Type", "application/json")
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(String.class)
                .block();  // Wait for response (blocking is okay here)

        // Step 4: Extract the useful part from Gemini's response
        return extractResponseContent(response);
    }

    // Digs through Gemini's JSON response to find the generated text
    private String extractResponseContent(String response) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(response);

            // Navigate: candidates → first item → content → parts → first part → text
            return String.valueOf(rootNode.path("candidates")
                            .get(0)
                            .path("content")
                            .path("parts")
                            .get(0)
                            .path("text"))
                    .replace("\n", "<br>");  // Add this line to convert newlines

        } catch (Exception e) {
            return "Error processing response: " + e.getMessage();  // User-friendly error
        }
    }

    // Builds the exact prompt we'll send to Gemini
    private String buildPrompt(EmailRequest emailRequest) {
        StringBuilder prompt = new StringBuilder();

        // Basic instructions
        prompt.append("Generate a professional email reply for the following email content. Do not add subject lines.");

        // Add tone if specified (e.g., "Use a friendly tone.")
        if (emailRequest.getTone() != null && !emailRequest.getTone().isEmpty()) {
            prompt.append(" Use a ").append(emailRequest.getTone()).append(" tone.");
        }

        // Append the original email we're replying to
        prompt.append("\nOriginal email: \n").append(emailRequest.getEmailContent());

        return prompt.toString();
    }
}